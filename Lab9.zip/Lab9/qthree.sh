#!/bin/bash

colours="Pink blue white green"

echo "My favourite colours are:" $colours
