#!/bin/bash

name="Inshika Thakur"
age=22
echo -e "My name is" $name ", and I am" $age "years old."
